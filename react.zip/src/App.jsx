import React, { useState, useEffect } from "react";
import { BrowserRouter , Routes, Route } from "react-router-dom";
import { Navigation } from "./components/navigation";
import { Header } from "./components/header";
import { Features } from "./components/features";
import { About } from "./components/about";
import { Services } from "./components/services";
import { Gallery } from "./components/gallery";
import { Testimonials } from "./components/testimonials";
import { Team } from "./components/Team";
import { Contact } from "./components/contact";
import JsonData from "./data/data.json";
import SmoothScroll from "smooth-scroll";
import "./App.css";
import { Home } from "./components/Home";
// const express = require("express");
// const cors = require("cors");
// const collection= require("./mongo")
// const app = express();
// app.use(express.json())
// app.use(express.urlencoded({extended:true}))
// app.use(cors())

// app.get ("/", cors(),(req,res)=>{
// })

// app.post ("/", async(req, res)=>{
//   const {name, email, message} = req.body
//   const data={name:name,
//   email:email,
//   message:message
// }

// await collection.insertMany([data])
// })

// app.listen(8000, ()=>{
//   console.log("port connect");
// })

export const scroll = new SmoothScroll('a[href*="#"]', {
  speed: 1000,
  speedAsDuration: true,
});

const App = () => {
  const [landingPageData, setLandingPageData] = useState({});
  useEffect(() => {
    setLandingPageData(JsonData);
  }, []);

  return (
    <div>
      <BrowserRouter>
      <Routes>
      {/* <Navigation /> */}
        <Route path="/" exact component={Home} />
        <Route path="/about" component={About} />
        <Route path="/features" component={Features} />
        <Route path="/services" component={Services} />
        <Route path="/testimonials" component={Testimonials} />
        <Route path="/contact" component={Contact} />
    </Routes>
   </BrowserRouter>
      </div>
  );
};

export default App;
