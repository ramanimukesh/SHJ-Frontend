import React ,{useState, useEffect} from "react";
import { BrowserRouter, Routes, Router, Route,  } from "react-router-dom";
import { Header } from "./header";
import { Features } from "./features";
import { About } from "./about";
import { Services } from "./services";
import { Gallery } from "./gallery";
import { Testimonials } from "./testimonials";
import { Team } from "./Team";
import { Contact } from "./contact";
import JsonData from "../data/data.json";
import SmoothScroll from "smooth-scroll";
import { Navigation } from "./navigation";


export const scroll = new SmoothScroll('a[href*="#"]', {
    speed: 1000,
    speedAsDuration: true,
  });

export const Home = () => {
    const [landingPageData, setLandingPageData] = useState({});
    useEffect(() => {
      setLandingPageData(JsonData);
    }, []);
    return (
    <p>home</p>
    );
  }
  
  {/* <Features data={landingPageData.Features} />
        <Services data={landingPageData.Services} />
        {/* <Gallery data={landingPageData.Gallery} /> */}
        // <Testimonials data={landingPageData.Testimonials}  />
        // {/* <Team data={landingPageData.Team} /> */}
        // <Contact data={landingPageData.Contact} /> */}